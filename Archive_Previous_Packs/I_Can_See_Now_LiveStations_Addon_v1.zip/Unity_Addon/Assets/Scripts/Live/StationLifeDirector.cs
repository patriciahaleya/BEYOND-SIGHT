using UnityEngine;
using System.Collections.Generic;

public class StationLifeDirector : MonoBehaviour
{
    public TalkSingClap Voice;
    public StoryReader Reader;

    [System.Serializable] public class LiveDef {
        public string name, color, accent, glow, talk, sing, clap;
        public List<string> read_lines;
        public List<string> special;
    }
    [System.Serializable] class Wrapper { public List<LiveDef> stations; }
    private Dictionary<string, LiveDef> map = new Dictionary<string, LiveDef>();

    void Awake()
    {
        var ta = Resources.Load<TextAsset>("Config/LiveStations");
        var w = JsonUtility.FromJson<Wrapper>(ta.text);
        foreach (var s in w.stations) map[s.name] = s;
        EventBus.On("station.changed", OnStation);
    }

    void OnDestroy(){ EventBus.Off("station.changed", OnStation); }

    void OnStation(string stationName)
    {
        if (!map.ContainsKey(stationName)) return;
        var s = map[stationName];
        // Color glow
        Color c; if (ColorUtility.TryParseHtmlString(s.color, out c) && Camera.main!=null) Camera.main.backgroundColor = c;
        // Talk line
        if (Voice!=null && !string.IsNullOrEmpty(s.talk)) Voice.Talk(s.talk);
        // Glow special
        if (s.glow=="ripples") Shader.SetGlobalFloat("_RippleStrength", 1f);
        if (s.glow=="candle") Shader.SetGlobalFloat("_CandleFlicker", 1f);
        if (s.glow=="heartbeat_bloom") Shader.SetGlobalFloat("_HeartBloom", 1f);
        // Station specials
        foreach (var sp in s.special) EventBus.Broadcast("live.special", sp);
        // Prep reader
        if (Reader!=null) Reader.LoadLines(s.read_lines.ToArray());
    }

    // Editor keys to demo
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T)) Voice?.Talk("Hello! This station speaks.");
        if (Input.GetKeyDown(KeyCode.S)) Voice?.Sing("DemoSong");
        if (Input.GetKeyDown(KeyCode.C)) Voice?.Clap("joy");
        if (Input.GetKeyDown(KeyCode.L)) Reader?.ReadNext();
    }
}