using UnityEngine;

// Reads a series of lines on demand (connect to braille/touch triggers)
public class StoryReader : MonoBehaviour
{
    public AudioSource Voice;
    private string[] lines;
    private int index = 0;

    public void LoadLines(string[] ls){ lines = ls; index = 0; }
    public void ReadNext()
    {
        if (lines==null || lines.Length==0) return;
        string l = lines[index];
        Debug.Log("[Read] " + l);
        if (Voice) Voice.Play();
        index = (index + 1) % lines.Length;
    }
}