using UnityEngine;

// Example one-line bindings to make stations "do their thing"
public class EventBindings : MonoBehaviour
{
    public ParticleSystem Fireflies, Ripples, Pollen, Butterflies, NumberSparks;
    public AudioSource FishSplash;

    void OnEnable(){ EventBus.On("live.special", OnSpecial); }
    void OnDisable(){ EventBus.Off("live.special", OnSpecial); }

    void OnSpecial(string sp)
    {
        switch(sp)
        {
            case "fish_jump":
                if (FishSplash) { FishSplash.transform.position = Random.insideUnitSphere; FishSplash.Play(); }
                if (Ripples) Ripples.Play();
                break;
            case "pollen_sparkles": if (Pollen) Pollen.Play(); break;
            case "butterflies_flutter": if (Butterflies) Butterflies.Play(); break;
            case "number_sparks": if (NumberSparks) NumberSparks.Play(); break;
            case "braille_glow": Shader.SetGlobalFloat("_BrailleGlow", 1f); break;
            case "fireflies": if (Fireflies) Fireflies.Play(); break;
            default: break;
        }
    }
}