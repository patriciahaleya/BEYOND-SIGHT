using UnityEngine;

// Simple real-time speech/sing/clap orchestrator (audio clips or TTS hooks)
public class TalkSingClap : MonoBehaviour
{
    public AudioSource TalkSource;
    public AudioSource SingSource;
    public AudioSource ClapSource;

    public void Talk(string line)
    {
        Debug.Log("[Talk] " + line);
        if (TalkSource) TalkSource.Play(); // Replace with TTS
        HapticsEngine h = FindObjectOfType<HapticsEngine>(); if (h) h.PlayPattern("enter");
    }

    public void Sing(string title)
    {
        Debug.Log("[Sing] " + title);
        if (SingSource) SingSource.Play();
        EventBus.Broadcast("music.request", title);
    }

    public void Clap(string pattern)
    {
        Debug.Log("[Clap] " + pattern);
        if (ClapSource) ClapSource.Play();
        HapticsEngine h = FindObjectOfType<HapticsEngine>(); if (h) h.PlayPattern("joy");
    }
}