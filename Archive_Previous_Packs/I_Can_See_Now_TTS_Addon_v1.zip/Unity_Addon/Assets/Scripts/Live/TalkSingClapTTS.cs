using UnityEngine;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Text;

/// Replaces Talk/Sing/Clap with real on‑device TTS across platforms.
public class TalkSingClapTTS : MonoBehaviour
{
    public static string Language = "en-US";

#if UNITY_ANDROID && !UNITY_EDITOR
    // Android TextToSpeech fields
    private AndroidJavaObject tts;
    private bool ttsReady = false;

    private class OnInitListener : AndroidJavaProxy
    {
        private TalkSingClapTTS owner;
        public OnInitListener(TalkSingClapTTS o) : base("android.speech.tts.TextToSpeech$OnInitListener"){ owner=o; }
        void onInit(int status){ owner.ttsReady = (status == 0); }
    }

    void Start()
    {
        var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        var activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
        tts = new AndroidJavaObject("android.speech.tts.TextToSpeech", activity, new OnInitListener(this));
    }
#endif

    public void Talk(string text)
    {
        Speak(text);
        Haptics("enter");
    }
    public void Sing(string lyric)
    {
        Speak("Singing: " + lyric);
        Haptics("joy");
    }
    public void Clap(string pattern)
    {
        Speak("Clap clap for you!");
        Haptics("joy");
    }

    private void Haptics(string pattern)
    {
        var h = FindObjectOfType<HapticsEngine>();
        if (h != null) h.PlayPattern(pattern);
    }

    public void Speak(string text)
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (tts == null) return;
        if (!ttsReady) { UnityEngine.Debug.Log("[TTS Android] Not ready yet, queuing."); return; }
        var paramsMap = new AndroidJavaObject("java.util.HashMap");
        tts.Call<int>("setLanguage", new AndroidJavaObject("java.util.Locale", Language));
        tts.Call<int>("speak", text, 0, paramsMap, "utteranceId");
#elif UNITY_IOS && !UNITY_EDITOR
        _SpeakIOS(text, Language);
#elif UNITY_STANDALONE_OSX && !UNITY_EDITOR
        RunProcess("/usr/bin/say", "-v Samantha " + Quote(text));
#elif UNITY_STANDALONE_WIN && !UNITY_EDITOR
        // Use PowerShell with System.Speech (installed by default on Windows)
        string ps = "Add-Type -AssemblyName System.Speech; " +
                    "$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
                    f"$speak.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::NotSet, [System.Speech.Synthesis.VoiceAge]::Adult, 0, [System.Globalization.CultureInfo]::GetCultureInfo('{Language}')); " +
                    "$speak.Speak('" + EscapeForPowerShell(text) + "');";
        RunProcess("powershell.exe", "-NoProfile -Command " + Quote(ps));
#else
        UnityEngine.Debug.Log("[TTS Simulated] " + text);
#endif
    }

#if UNITY_IOS && !UNITY_EDITOR
    [DllImport("__Internal")] private static extern void _SpeakIOS(string message, string lang);
#endif

#if UNITY_STANDALONE && !UNITY_EDITOR
    private static void RunProcess(string file, string args)
    {
        try
        {
            var p = new Process();
            p.StartInfo.FileName = file;
            p.StartInfo.Arguments = args;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.UseShellExecute = false;
            p.Start();
        }
        catch (System.Exception e){ UnityEngine.Debug.LogWarning("[TTS Desktop] " + e.Message); }
    }
    private static string Quote(string s) => "\"" + s.Replace("\"","\\\"") + "\"";
    private static string EscapeForPowerShell(string s) => s.Replace("'", "''");
#endif
}
