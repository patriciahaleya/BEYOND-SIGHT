# I Can See Now — On‑Device TTS Add‑On (v1)
Generated: 2025-10-27

This add‑on **replaces Talk with real on‑device Text‑to‑Speech** across platforms:
- **iOS/iPadOS:** AVSpeechSynthesizer (offline, system voices)
- **Android / Meta Quest:** Android TextToSpeech API
- **Windows (Standalone):** PowerShell → System.Speech.Synthesis
- **macOS (Standalone):** `say` command

## How to Install (3 minutes)
1) Unzip and drag **Unity_Addon/Assets/** into your Unity 2022.3 project.
2) On your scene GameObject (that had TalkSingClap), **remove old TalkSingClap.cs** and add **TalkSingClapTTS.cs**.
3) iOS: Xcode will auto-build the native bridge in `Plugins/iOS/TTSBridge.mm`.
4) Android/Quest: No extra plugin needed. The C# script initializes TextToSpeech once and reuses it.
5) Desktop: Works out of the box. (Windows uses PowerShell; macOS uses `say`).

## API (drop‑in replacement)
```csharp
var tts = GetComponent<TalkSingClapTTS>();
tts.Talk("Blue river. Listen to the flow.");
tts.Sing("Happy song");
tts.Clap("joy");
```

## Notes
- iOS/Android run entirely on device (no internet).
- Adjust language: `TalkSingClapTTS.Language = "en-US";` (e.g., "es-ES", "fr-FR").
- For Android, the first TTS init can take ~1s; calls queue until ready.
- For Windows, PowerShell must be available; macOS uses built-in `say`.
