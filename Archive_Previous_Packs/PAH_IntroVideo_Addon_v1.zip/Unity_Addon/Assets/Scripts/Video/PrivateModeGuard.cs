using UnityEngine;

// Use with Scripting Define Symbol: PRIVATE_BUILD
// Hides external links, disables analytics calls, and blocks any accidental web requests.
public class PrivateModeGuard : MonoBehaviour
{
    void Awake()
    {
#if PRIVATE_BUILD
        Application.targetFrameRate = 72;
        DisableUnityAnalytics();
        BlockWeb();
#endif
    }

    void DisableUnityAnalytics()
    {
        // If Unity Analytics is present, attempt to disable.
        var type = System.Type.GetType("UnityEngine.Analytics.Analytics, UnityEngine.Analytics");
        if (type != null)
        {
            var prop = type.GetProperty("enabled");
            if (prop != null && prop.CanWrite) prop.SetValue(null, false, null);
        }
    }

    void BlockWeb()
    {
        // Soft guard: if code ever tries to check internet, treat it as not reachable
        if (Application.internetReachability != NetworkReachability.NotReachable)
        {
            Debug.LogWarning("[PrivateMode] Network is reachable. Ensure no networking is used.");
        }
    }
}
