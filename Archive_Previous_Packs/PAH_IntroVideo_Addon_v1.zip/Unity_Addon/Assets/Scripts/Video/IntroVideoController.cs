using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class IntroVideoController : MonoBehaviour
{
    public VideoPlayer MainVideo;
    public VideoPlayer AslVideo; // corner overlay
    public RawImage MainTarget;
    public RawImage AslTarget;
    public SimpleSrtCaptions Captions;
    public Text Watermark;
    public Button SkipButton;
    public string NextScene = "Main";
    public bool PinGate = false;
    public string Pin = "2025";

    void Start()
    {
        Application.runInBackground = false;
        SetupWatermark();
        LoadVideos();
        if (SkipButton) SkipButton.onClick.AddListener(Skip);
        if (PinGate) ShowPinGate();
    }

    void SetupWatermark()
    {
        if (Watermark) Watermark.text = "CONFIDENTIAL — Not for Public Release";
    }

    void LoadVideos()
    {
        string sa = Application.streamingAssetsPath;
        string mainPath = System.IO.Path.Combine(sa, "I_Can_See_Now_Intro.mp4");
        string aslPath = System.IO.Path.Combine(sa, "I_Can_See_Now_ASL_Overlay.mp4");

        if (System.IO.File.Exists(mainPath))
        {
            MainVideo.url = mainPath;
            MainVideo.isLooping = false;
            MainVideo.prepareCompleted += (v)=> { v.Play(); Captions?.ResetTimer(); };
            MainVideo.loopPointReached += (v)=> EndIntro();
            MainVideo.Prepare();
        }
        else
        {
            // Friendly fallback if video missing
            if (Watermark) Watermark.text += "\n[Video not found — place files in StreamingAssets]";
        }

        if (System.IO.File.Exists(aslPath))
        {
            AslVideo.url = aslPath;
            AslVideo.isLooping = true;
            AslVideo.Prepare();
            AslVideo.prepareCompleted += (v)=> v.Play();
        }
    }

    public void Skip()
    {
        EndIntro();
    }

    void EndIntro()
    {
        PlayerPrefs.SetInt("pah.intro.seen", 1);
        SceneManager.LoadScene(NextScene);
    }

    void ShowPinGate()
    {
        // Optional: display a simple pin UI; for brevity, use Return key to bypass
        // You can wire a real field in the Canvas to call ValidatePin(string).
    }

    public void ValidatePin(string entered)
    {
        if (entered == Pin) { /* allow playback */ }
    }
}
