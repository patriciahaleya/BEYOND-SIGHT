# PAH Intro Video Add-on (Private Edition) — v1
Generated: 2025-10-27

This package adds a **private, offline intro video** scene to your MASTER EDITION Unity project.
It includes dual VideoPlayers (main video + ASL window), on-screen captions (SRT),
and a soft **CONFIDENTIAL** watermark for in-hospital previews.

## Files
- Scenes/PAH_IntroVideo.unity   (scene placeholder)
- Scripts/Video/IntroVideoController.cs
- Scripts/Video/SimpleSrtCaptions.cs
- Scripts/Video/PrivateModeGuard.cs
- Resources/Subtitles/I_Can_See_Now_Intro.srt (sample captions; replace with your final timing)
- Docs/Integration_Steps.txt

## Expected StreamingAssets (you add these large files yourself)
- StreamingAssets/I_Can_See_Now_Intro.mp4
- StreamingAssets/I_Can_See_Now_ASL_Overlay.mp4
- StreamingAssets/Subtitles/I_Can_See_Now_Intro.srt (optional override)

> Note: These are **NOT** included here to keep the ZIP small and private.
> Drop your final media in StreamingAssets to play offline on iOS/Android/PC/Quest.

## Private Mode Defaults
- No internet calls; no analytics; no crash upload.
- Watermark "CONFIDENTIAL — Not for Public Release" (top-left, subtle gold).
- Optional pin-gate before playback.
- Script define: PRIVATE_BUILD (enable in Player Settings to hide outward links).

