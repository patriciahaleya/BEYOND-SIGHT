using UnityEngine; using UnityEngine.SceneManagement;
public class AppStart {
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Early(){ if(PlayerPrefs.GetInt("pah.intro.seen",0)==0) SceneManager.LoadScene("PAH_IntroVideo"); }
}