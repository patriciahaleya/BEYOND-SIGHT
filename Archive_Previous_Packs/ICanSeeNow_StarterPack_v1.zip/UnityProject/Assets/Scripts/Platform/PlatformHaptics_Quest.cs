#if UNITY_ANDROID && !UNITY_EDITOR
using UnityEngine;

// Quest-specific (placeholder). Replace with OVRInput/Meta SDK calls if imported.
public class PlatformHaptics_Quest : HapticsController
{
    public override void Pulse(float duration, float intensity)
    {
        // OVRInput.SetControllerVibration(freq, amp, controller) – when Oculus Integration is added
        Debug.Log($"[Haptics:Quest] {duration}s {intensity}");
    }
}
#endif
