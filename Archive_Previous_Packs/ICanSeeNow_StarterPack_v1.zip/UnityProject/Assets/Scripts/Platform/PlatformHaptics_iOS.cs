#if UNITY_IOS
using UnityEngine;
using System.Runtime.InteropServices;

// iOS-specific (placeholder). For real Core Haptics, add a native plugin and call into it.
public class PlatformHaptics_iOS : HapticsController
{
    public override void Pulse(float duration, float intensity)
    {
        Handheld.Vibrate(); // simple fallback
        Debug.Log($"[Haptics:iOS] {duration}s {intensity}");
    }
}
#endif
