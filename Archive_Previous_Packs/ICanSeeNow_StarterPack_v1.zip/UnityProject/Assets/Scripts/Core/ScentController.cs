using UnityEngine;

// Abstract scent API so hardware can be swapped later
public class ScentController : MonoBehaviour, IScentProvider
{
    public void Emit(string aroma, float strength)
    {
        Debug.Log($"[Scent] Emit {aroma} @ {strength} (placeholder)");
        // TODO: call into BLE/USB diffuser when available
    }
}

public interface IScentProvider
{
    void Emit(string aroma, float strength);
}
