using UnityEngine;
using System.Collections.Generic;
using System.Linq;

// I Can See Now – SenseManager
// Central app brain: loads stations, routes input, randomizes sound signatures.
public class SenseManager : MonoBehaviour
{
    public StationRouter Router;
    public FaithFriend FaithFriend;
    public AudioSource GlobalAudio;

    private int currentStationIndex = 0;
    private List<StationDefinition> stations = new List<StationDefinition>();

    void Awake()
    {
        stations = StationConfigLoader.Load();
        if (stations.Count == 0) Debug.LogWarning("No stations loaded.");
        Router.Init(stations);
        SwitchToStation(0);
    }

    void Update()
    {
        // Desktop/editor number keys 1..7 to switch stations
        for (int i = 0; i < stations.Count && i < 9; i++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
                SwitchToStation(i);
        }

        if (Input.GetKeyDown(KeyCode.R)) Router.RandomizeVariation();
        if (Input.GetKeyDown(KeyCode.M)) FaithFriend.PlayRequestedSong("Amazing Grace");
        if (Input.GetKeyDown(KeyCode.Q)) FaithFriend.AnswerQuestion("Why does thunder sound different?");
    }

    public void SwitchToStation(int index)
    {
        currentStationIndex = Mathf.Clamp(index, 0, stations.Count - 1);
        Router.SwitchTo(stations[currentStationIndex]);
        RenderSettings.ambientLight = Color.white;
        Camera.main.backgroundColor = stations[currentStationIndex].UnityColor();
        Debug.Log($"[SenseManager] Station → {stations[currentStationIndex].name}");
    }
}
