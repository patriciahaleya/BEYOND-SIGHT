using UnityEngine;

// Attach to AudioSources for animals/rain/etc and randomize each play
public class SoundSignature : MonoBehaviour
{
    public float pitchMin = 0.9f;
    public float pitchMax = 1.1f;
    public float volMin = 0.6f;
    public float volMax = 1.0f;

    private AudioSource src;

    void Awake() { src = GetComponent<AudioSource>(); if (src==null) src = gameObject.AddComponent<AudioSource>(); }

    public void Play()
    {
        src.pitch = Random.Range(pitchMin, pitchMax);
        src.volume = Random.Range(volMin, volMax);
        src.spatialBlend = 1f;
        src.Play();
    }
}
