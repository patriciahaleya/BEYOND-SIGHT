using UnityEngine;

// Cross-platform haptics abstraction; platform impls can override
public class HapticsController : MonoBehaviour
{
    public virtual void Pulse(float duration, float intensity)
    {
        // Desktop/Editor placeholder
        Handheld.Vibrate();
        Debug.Log($"[Haptics] Pulse {duration}s @ {intensity}");
    }
}
