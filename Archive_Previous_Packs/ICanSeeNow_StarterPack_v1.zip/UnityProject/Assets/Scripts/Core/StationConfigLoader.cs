using UnityEngine;
using System.Collections.Generic;
using System.IO;

public static class StationConfigLoader
{
    public static List<StationDefinition> Load()
    {
        TextAsset json = Resources.Load<TextAsset>("Config/Stations");
        if (json == null) { Debug.LogWarning("Stations.json not found"); return new List<StationDefinition>(); }
        Wrapper w = JsonUtility.FromJson<Wrapper>(json.text);
        return w.stations;
    }

    [System.Serializable]
    class Wrapper { public List<StationDefinition> stations; }
}
