using UnityEngine;

// Simple placeholder for voice Q&A + song requests
public class FaithFriend : MonoBehaviour
{
    public AudioSource Voice;
    public AudioSource Music;

    public void AnswerQuestion(string question)
    {
        Debug.Log("[FaithFriend] Q: " + question);
        // Placeholder: respond with logs & beep
        if (Voice != null) Voice.Play();
    }

    public void PlayRequestedSong(string title)
    {
        Debug.Log("[FaithFriend] Playing requested song: " + title);
        if (Music != null) Music.Play();
    }
}
