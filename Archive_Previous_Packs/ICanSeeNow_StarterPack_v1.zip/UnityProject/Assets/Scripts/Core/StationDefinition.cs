using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class StationDefinition
{
    public int id;
    public string name;
    public string color;
    public string aroma;
    public string ambience;
    public List<string> sfx;

    public Color UnityColor()
    {
        Color c = Color.black;
        if (ColorUtility.TryParseHtmlString(color, out c)) return c;
        return c;
    }
}
