using UnityEngine;
using System.Collections.Generic;

// Routes to station behaviors and handles ambience & SFX sets
public class StationRouter : MonoBehaviour
{
    public AudioSource Ambience;
    public AudioSource Sfx;
    public HapticsController Haptics;
    public ScentController Scent;

    private StationDefinition current;

    public void Init(List<StationDefinition> defs)
    {
        // placeholder init
    }

    public void SwitchTo(StationDefinition def)
    {
        current = def;
        // Scent & haptics
        if (Scent != null) Scent.Emit(def.aroma, 0.5f);
        if (Haptics != null) Haptics.Pulse(0.2f, 0.6f);

        // Ambience cue placeholder
        if (Ambience != null)
        {
            Ambience.spatialBlend = 1f;
            Ambience.pitch = Random.Range(0.95f, 1.05f);
            Ambience.Play(); // assign clip at editor time
        }
    }

    public void RandomizeVariation()
    {
        if (Ambience != null)
        {
            Ambience.pitch = Random.Range(0.85f, 1.15f);
            Ambience.volume = Random.Range(0.5f, 1.0f);
        }
        if (Sfx != null) Sfx.Play();
        if (Haptics != null) Haptics.Pulse(Random.Range(0.05f,0.3f), Random.Range(0.3f,1f));
    }
}
