# I Can See Now – Living World of Senses
*A Patricia Haley Charity Innovation* • *Created by Patricia Haley*

Version: 1.0  •  Generated: 2025-10-26

This starter pack gives you a **single Unity codebase** that targets:
- **VR (Meta Quest 3 / OpenXR)**
- **Desktop (Windows/Mac)** 
- **iOS (iPhone/iPad)**

It includes scripts and configuration stubs for:
- Multisensory **Stations** (Touch, Sound, Smell, Story, Math, Adventure, Joy)
- **FaithFriend** avatar (voice Q&A + music requests)
- **Sound Signatures** (animals, rain, thunder, baby, butterfly, flowers)
- **Haptics** (Quest controllers, iPhone/iPad vibration) and **Scent** interface (for future diffuser)
- **Privacy-first, offline** operation

> This is a scaffolding pack. Open in **Unity 2022.3 LTS (Built-in RP)** and add content/assets as described below.

---

## 1) Open & Run (Quick Start)
1. Install **Unity 2022.3 LTS**.
2. Open the folder: `UnityProject/` in Unity Hub (create a new 3D project if Unity prompts, then copy Assets in).
3. In Unity, create a scene named **Main.unity** inside `Assets/Scenes/` and add **GameObject → Empty** named `App`.
4. Add the components below to `App`:
   - `SenseManager.cs`
   - `StationRouter.cs`
   - `FaithFriend.cs`
5. Press **Play**. You’ll hear placeholder audio beeps and can switch stations with number keys **1–7**.

---

## 2) Platform Build Profiles
### VR — Meta Quest 3 (Android/OpenXR)
- **File → Build Settings → Android**
- **Player Settings → XR Plug‑in Management → OpenXR** (enable)
- Add **Oculus Touch Controller Profile** in OpenXR features
- **Target FPS:** 72
- **Minimum SDK:** 29
- **Scripting Backend:** IL2CPP
- **ARM64 only**

### Desktop — Windows/Mac
- **Build Settings → PC, Mac & Linux Standalone**
- **Resolution:** Fullscreen Windowed
- **Audio:** Enable spatial blend on AudioSources (set 3D)

### iOS — iPhone/iPad
- **Build Settings → iOS**
- **Scripting Backend:** IL2CPP • **Target minimum iOS:** 15.0
- In Xcode: set **Team** → your Apple ID, **Signing** enabled
- On device, allow **Microphone** permission (voice Q&A)
- Haptics: uses simple vibration fallback; Core Haptics can be added later

---

## 3) Project Layout
```
Assets/
  Resources/Config/Stations.json         # Station definitions
  Scripts/
    Core/  (managers & data)
    Stations/ (station behaviors)
    Platform/ (haptics/scent per platform)
  Scenes/ (create Main.unity here)
```

---

## 4) Add Your Content
- Drop ambient/animal sounds into `Assets/Resources/` and reference them in `Stations.json`.
- Replace placeholder Q&A in `FaithFriend.cs` with your script set.
- Connect scent hardware later by implementing `IScentProvider` (see `ScentController.cs`).

---

## 5) Controls (Editor/Desktop)
- **1..7** = Switch station
- **R** = Randomize sound variation
- **M** = Music request demo
- **Q** = Ask a question (console input placeholder)

> For VR, map the same to **A/B/X/Y** and thumbstick press (see `InputBindings` section in `SenseManager.cs`).

---

## 6) Safety & Privacy
- No cloud, no tracking by default. All data local.
- Microphone input is processed locally (placeholder). Replace with on-device ASR when available or approved.

---

## 7) Next Steps
- Add **real sound libraries** (animals, rain, thunder, baby).
- Record **FaithFriend** voice lines in 6 languages (EN/ES/FR/AR/ZH/JA).
- Integrate **heart-rate straps** for calming (optional).
- Implement **scent diffuser** driver (USB/BLE) via `IScentProvider`.

Blessings on this build — let’s make a world blind children can *feel and hear*.
