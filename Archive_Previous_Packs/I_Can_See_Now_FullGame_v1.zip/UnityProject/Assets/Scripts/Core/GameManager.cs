using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public StationRouter Router;
    public QuestSystem Quest;
    public InventorySystem Inventory;
    public FaithFriendRealtime Friend;

    public int CurrentStationIndex = 0;

    void Start()
    {
        if (Router==null) Router = GetComponent<StationRouter>();
        if (Quest==null) Quest = GetComponent<QuestSystem>();
        if (Inventory==null) Inventory = GetComponent<InventorySystem>();
        SwitchStation(0);
        Friend.PlayRequestedSong("Welcome");
        Quest.AnnounceStationGoals(CurrentStationIndex);
    }

    void Update()
    {
        for(int i=0;i<7;i++) if (Input.GetKeyDown(KeyCode.Alpha1+i)) SwitchStation(i);
        if (Input.GetKeyDown(KeyCode.Space)) Quest.CompleteStep(); // demo confirm
    }

    public void SwitchStation(int idx)
    {
        CurrentStationIndex = idx;
        Router.SwitchToByIndex(idx);
        Quest.SetStation(idx);
    }
}
