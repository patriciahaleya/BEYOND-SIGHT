using UnityEngine;

public class HapticsEngine : MonoBehaviour
{
    public void PlayPattern(string name, float intensity=0.7f){ Handheld.Vibrate(); }
}
