using UnityEngine;

public class FaithFriendRealtime : MonoBehaviour
{
    public AudioSource Voice;
    public AudioSource Music;

    public void PlayRequestedSong(string title){ if (Music) Music.Play(); }
    public void Say(string text){ Debug.Log("[FaithFriend] " + text); if (Voice) Voice.Play(); }
}
