using UnityEngine;

public class MusicConductor : MonoBehaviour
{
    public AudioSource A;
    public AudioSource B;
    bool a = true;
    public void Pulse(){ if (a){ if(B) B.Play(); } else { if(A) A.Play(); } a=!a; }
}
