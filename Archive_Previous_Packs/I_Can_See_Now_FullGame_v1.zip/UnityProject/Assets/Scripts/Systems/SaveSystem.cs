using UnityEngine;

public class SaveSystem : MonoBehaviour
{
    public void SaveInt(string key, int val){ PlayerPrefs.SetInt(key,val); PlayerPrefs.Save(); }
    public int LoadInt(string key, int def=0){ return PlayerPrefs.GetInt(key, def); }
    public void SaveString(string key, string val){ PlayerPrefs.SetString(key,val); PlayerPrefs.Save(); }
    public string LoadString(string key, string def=""){ return PlayerPrefs.GetString(key, def); }
}
