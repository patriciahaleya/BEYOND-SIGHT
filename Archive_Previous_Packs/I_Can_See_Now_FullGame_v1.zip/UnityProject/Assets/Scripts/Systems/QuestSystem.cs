using UnityEngine;
using System.Collections.Generic;

public class QuestSystem : MonoBehaviour
{
    private int stationIndex = 0;
    private int step = 0;
    private List<StationDef> defs;

    void Awake(){ defs = StationDef.LoadAll(); }

    public void SetStation(int idx){ stationIndex = idx; step = 0; AnnounceStationGoals(idx); }

    public void AnnounceStationGoals(int idx)
    {
        var d = defs[idx];
        Debug.Log("[Quest] Goals for " + d.name + ": " + string.Join(", ", d.quests));
        EventBus.Broadcast("quest.goals", d.name);
    }

    public void CompleteStep()
    {
        var d = defs[stationIndex];
        if (step < d.quests.Length) step++;
        if (step >= d.quests.Length)
        {
            EventBus.Broadcast("quest.complete", d.name);
            FindObjectOfType<InventorySystem>().AddLightSeed(1);
            Debug.Log("[Quest] Light Seed earned! Total: " + PlayerPrefs.GetInt("inv.seeds",0));
            step = 0; // loop
        }
        else
        {
            Debug.Log("[Quest] Step " + step + "/" + d.quests.Length);
        }
    }
}
