using UnityEngine;

public class MiniGameRiverRhythm : MonoBehaviour
{
    private int beats = 3;
    public void StartRhythm(){ beats = Random.Range(3,6); Debug.Log("[RiverRhythm] Tap " + beats + " beats with Space."); }
    public void Tap(){ beats--; if (beats<=0) Debug.Log("[RiverRhythm] Success!"); }
}
