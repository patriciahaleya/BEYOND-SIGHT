using UnityEngine;

public class MiniGameAnimalID : MonoBehaviour
{
    public AudioSource Cat, Bird, Frog;
    public void PlayRound()
    {
        int pick = Random.Range(0,3);
        var src = pick==0?Cat: pick==1?Bird:Frog;
        if (src) { src.spatialBlend=1f; src.Play(); }
        Debug.Log("[AnimalID] Which animal? Press Space to confirm.");
    }
}
