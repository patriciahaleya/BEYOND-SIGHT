using UnityEngine;
using System.Collections;

public class MiniGameJoyBreath : MonoBehaviour
{
    public Light Ambient;
    public IEnumerator StartSession()
    {
        for(int i=0;i<3;i++)
        {
            yield return Breathe();
        }
        Debug.Log("[JoyBreath] Peace achieved.");
    }

    IEnumerator Breathe()
    {
        float t=0f,d=6f;
        while(t<d){ t+=Time.deltaTime; if(Ambient) Ambient.intensity = 1f + Mathf.Sin(t/d*Mathf.PI); yield return null; }
    }
}
