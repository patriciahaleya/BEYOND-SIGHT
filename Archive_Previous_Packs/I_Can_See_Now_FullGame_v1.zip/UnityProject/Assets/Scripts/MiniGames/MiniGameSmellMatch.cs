using UnityEngine;

public class MiniGameSmellMatch : MonoBehaviour
{
    string[] scents = new string[]{"Rose","Orange","Mint"};
    int target = 0;
    public void NewRound(){ target = Random.Range(0,scents.Length); Debug.Log("[SmellMatch] Find " + scents[target]); }
    public void Pick(int i){ Debug.Log(i==target? "[SmellMatch] Correct!" : "[SmellMatch] Try again"); }
}
