using UnityEngine;

public class MiniGameSafeSteps : MonoBehaviour
{
    int steps;
    public void NewRound(){ steps=3; Debug.Log("[SafeSteps] Follow 3 taps to the door. Space to step."); }
    public void Step(){ steps--; if(steps<=0) Debug.Log("[SafeSteps] Door reached!"); }
}
