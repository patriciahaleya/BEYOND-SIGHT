using UnityEngine;

public class MiniGameStoryTouch : MonoBehaviour
{
    int line=0;
    public void StartStory(){ line=0; Debug.Log("[StoryTouch] Read lines 1-2-3 with Space."); }
    public void TouchLine(){ line++; Debug.Log(line>=3? "[StoryTouch] Story complete!":"[StoryTouch] Next line..."); }
}
