using UnityEngine;

public class MiniGameMathShapes : MonoBehaviour
{
    int a,b;
    public void NewRound(){ a=Random.Range(1,3); b=Random.Range(1,3); Debug.Log("[MathShapes] Touch count: "+a+" + "+b); }
    public void Answer(int v){ Debug.Log(v==(a+b)? "[MathShapes] Correct!":"[MathShapes] Try again"); }
}
