using UnityEngine;
using UnityEngine.UI;

public class CanvasController : MonoBehaviour
{
    public Text Title, Body, Progress;
    void OnEnable()
    {
        EventBus.On("station.changed", s=> { if(Title) Title.text = s; });
        EventBus.On("quest.goals", s=> { if(Body) Body.text = "New goals in " + s; });
    }
}
