# I Can See Now — Full Game v1
*A Patricia Haley Charity Innovation* — *Created by Patricia Haley*

Generated: 2025-10-27

A **full game loop** for VR • Desktop • iPad/iPhone that talks, sings, glows,
and teaches through seven stations + family hub. It includes:

- **Main loop:** explore stations → complete minigames → collect **Light Seeds** → earn **Heart Medals** → unlock new songs & scents.
- **Quests:** FaithFriend gives objectives; progress is saved locally.
- **Minigames:** Animal ID, River Rhythm, Smell Match (simulated), Math Shapes, Safe Steps (orientation), Story Touch, Joy Breathing.
- **Systems:** Save/Load, Inventory (Seeds/Medals/Scents/Songs), Haptics, Aroma hooks, Adaptive Music.
- **UI:** Large fonts, voice prompts, high-contrast, controller & keyboard shortcuts.

> Open in **Unity 2022.3 LTS** (Built‑in or URP). Plug in your real audio/assets later.

## Quick Start
1) Open `UnityProject/` in Unity.
2) Create `Assets/Scenes/Main.unity` and add an empty GameObject **App**.
3) Attach to **App** in this order:
   - Core: `GameManager`, `StationRouter`, `FaithFriendRealtime`
   - Systems: `SaveSystem`, `InventorySystem`, `QuestSystem`, `MusicConductor`, `HapticsEngine`, `AromaController`
   - MiniGames: `MiniGameAnimalID`, `MiniGameRiverRhythm`, `MiniGameSmellMatch`, `MiniGameMathShapes`, `MiniGameSafeSteps`, `MiniGameStoryTouch`, `MiniGameJoyBreath`
4) In **GameManager**, assign the Text UI fields if you add a Canvas (optional). Press **Play**.

## Controls
- **1..7**: child stations • **F1..F6**: family stations
- **Space / A (VR button)**: Interact/Confirm
- **M**: Music request • **V**: simulate question • **R**: randomize env • **H**: haptics

## Build
- Quest (Android/OpenXR), Desktop, iOS 15+ (mic permission).

See `Docs/Design_GDD.txt` for full design.
