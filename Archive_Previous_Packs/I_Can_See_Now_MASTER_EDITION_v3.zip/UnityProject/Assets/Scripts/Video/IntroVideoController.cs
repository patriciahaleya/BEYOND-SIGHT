using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using UnityEngine.SceneManagement;

public class IntroVideoController : MonoBehaviour
{
    [Header("Video Players")]
    public VideoPlayer MainVideo;
    public VideoPlayer AslVideo; // corner loop
    public RawImage MainTarget;
    public RawImage AslTarget;

    [Header("Captions & Watermark")]
    public SimpleSrtCaptions Captions;
    public Text Watermark;
    public bool ShowWatermark = true;

    [Header("Controls")]
    public Button SkipButton;
    public string NextScene = "Main";

    void Start()
    {
        if (ShowWatermark && Watermark) Watermark.text = "CONFIDENTIAL — Not for Public Release";
        LoadAndPlay();
        if (SkipButton) SkipButton.onClick.AddListener(EndIntro);
    }

    void LoadAndPlay()
    {
        string sa = Application.streamingAssetsPath;
        string mainPath = System.IO.Path.Combine(sa, "I_Can_See_Now_Intro.mp4");
        string aslPath  = System.IO.Path.Combine(sa, "I_Can_See_Now_ASL_Overlay.mp4");

        if (System.IO.File.Exists(mainPath))
        {
            MainVideo.url = mainPath;
            MainVideo.isLooping = false;
            MainVideo.prepareCompleted += (v)=> { v.Play(); Captions?.ResetTimer(); };
            MainVideo.loopPointReached += (v)=> EndIntro();
            MainVideo.Prepare();
        }
        else
        {
            if (Watermark) Watermark.text += "\n[Missing: StreamingAssets/I_Can_See_Now_Intro.mp4]";
        }

        if (System.IO.File.Exists(aslPath))
        {
            AslVideo.url = aslPath;
            AslVideo.isLooping = true;
            AslVideo.prepareCompleted += (v)=> v.Play();
            AslVideo.Prepare();
        }
    }

    public void EndIntro()
    {
        PlayerPrefs.SetInt("pah.intro.seen", 1);
        SceneManager.LoadScene(NextScene);
    }
}