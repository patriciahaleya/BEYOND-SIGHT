using UnityEngine;
using UnityEngine.SceneManagement;

public class AppStart : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void EarlyLaunch()
    {
        if (PlayerPrefs.GetInt("pah.intro.seen", 0) == 0)
        {
            SceneManager.LoadScene("PAH_IntroVideo");
        }
        // else: do nothing; Unity will open the scene you selected (e.g., Main.unity)
    }
}