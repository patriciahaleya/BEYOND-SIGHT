# I Can See Now — MASTER EDITION v3 (Auto-Play Intro • Soft & Calming)
Generated: 2025-10-27

This Unity 2022.3 project includes:
- Full app scaffolding (healing stations, Baby Mode, Ask FaithFriend Mom from v2)
- **PAH Intro Video** scene integrated with **auto-play on first launch**
- Captions + ASL window support (local-only, private)
- Soft & calming music profile

## Where to place media (local-only)
Put your final video assets here before building:
Assets/StreamingAssets/
 ├─ I_Can_See_Now_Intro.mp4          (main video with narration & music)
 ├─ I_Can_See_Now_ASL_Overlay.mp4    (ASL interpreter picture-in-picture)
 └─ Subtitles/I_Can_See_Now_Intro.srt

A sample SRT placeholder is included so you can preview timing immediately.

## Run flow
- On first app launch → loads **PAH_IntroVideo.unity** automatically
- After playback or Skip → goes to **Main.unity** (Healing Stations Hub)
- Later launches skip the intro (you can rewatch via “About PAH”)

## Private build
- No networking required; offline-ready
- Optional watermark “CONFIDENTIAL — Not for Public Release”
- (Recommended) Add Scripting Define Symbol: **PRIVATE_BUILD**

See Docs/Setup_v3.txt for steps.
