using UnityEngine;
public class HapticsEngine : MonoBehaviour { public void PlayPattern(string n){ Handheld.Vibrate(); } }
