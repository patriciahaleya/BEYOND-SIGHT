using UnityEngine;
public class SaveSystem : MonoBehaviour
{
    public void SaveInt(string k, int v){ PlayerPrefs.SetInt(k,v); PlayerPrefs.Save(); }
    public int LoadInt(string k, int d=0){ return PlayerPrefs.GetInt(k,d); }
    public void SaveString(string k, string v){ PlayerPrefs.SetString(k,v); PlayerPrefs.Save(); }
    public string LoadString(string k, string d=""){ return PlayerPrefs.GetString(k,d); }
}
