using UnityEngine;
public class ParentCoach:MonoBehaviour
{
    public TalkSingClapTTS TTS;
    public TextAsset GuideJson;
    private string[] lines = new string[] {
        "Introduce yourself: Hi, it's Mommy. I am on your left.",
        "Narrate: I'm lifting your right hand to touch the soft blanket.",
        "Warn before touch: I'm going to pick you up now."
    };
    void OnEnable(){ if(TTS==null) TTS = FindObjectOfType<TalkSingClapTTS>(); }
    public void NextTip(){ if (TTS!=null){ var i=Random.Range(0,lines.Length); TTS.Talk(lines[i]); } }
}