using UnityEngine;
public class EventBindings : MonoBehaviour
{
    public ParticleSystem Fireflies,Ripples,Butterflies,Pollen;
    void OnEnable(){ EventBus.On("station.changed",_=>{}); }
}
