using UnityEngine;
public class EventBusHost : MonoBehaviour {} // placeholder to ensure EventBus assembly compiles
