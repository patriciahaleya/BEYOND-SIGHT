# I Can See Now — MASTER EDITION (v1)
*A Patricia Haley Charity Innovation* — *Created by Patricia Haley*

Generated: 2025-10-27

This is a **single Unity project** you can open and run on:
- **VR (Meta Quest / OpenXR)**
- **Desktop (Windows/Mac)**
- **iPhone / iPad (iOS 15+)**

It includes:
- Full Game loop (quests, minigames, rewards, saving)
- Family Learning Stations
- Baby Mode (parent coaching)
- Live Stations (talk/sing/clap/read)
- On-device **Text-to-Speech** for Apple/Android/PC (offline)
- Aroma & Haptics hooks
- Colorful glow setup (URP/Builtin friendly)

## QUICK START
1) Open `UnityProject/` in **Unity 2022.3 LTS**.
2) Open **Scenes/Main.unity** (empty scene stub). Create an empty object **App**.
3) Add components to **App** (in this order):
   - Core: `GameManager`, `StationRouter`, `EventBusHost`
   - Systems: `SaveSystem`, `InventorySystem`, `QuestSystem`, `MusicConductor`, `HapticsEngine`, `AromaController`
   - Live: `StationLifeDirector`, `TalkSingClapTTS`, `StoryReader`, `EventBindings`
   - Family: `FamilyHub`, `SignLanguageTrainer`, `SongCreator`, `CareGuideStation`, `JoyPracticeStation`, `DailyJournal`
   - Baby: `BabyModeManager`, `ParentCoach`, `BabyActivity_VerbalCues`, `BabyActivity_SensoryPlay`, `BabyActivity_SpatialGuidance`, `BabyActivity_EarlyIntervention`
4) Press **Play**. Use keys: 1–7 (child stations), F1–F6 (family), **B** (toggle Baby Mode), **T/S/C/L** (talk/sing/clap/read demo).

## BUILD PROFILES
- **Meta Quest (VR):** Android, OpenXR, 72 FPS, ARM64/IL2CPP
- **Desktop:** PC/Mac Standalone
- **iOS:** iOS 15+, enable Microphone; Xcode auto-builds the TTS bridge

See `Docs/Setup_Wizard.txt` for copy/paste setup steps and `Docs/Build_Profiles.txt` for platform settings.
