# I Can See Now — MASTER EDITION v2 (with Ask FaithFriend Mom)
*A Patricia Haley Charity Innovation* — *Created by Patricia Haley*

Generated: 2025-10-27

One Unity 2022.3 LTS project for: **Meta Quest (VR)** • **Desktop** • **iPhone/iPad**.
Includes: Full Game + Family Stations + Baby Mode + Live Stations + On‑device TTS + AskFaithFriendMom.

## Quick Start
1) Open `UnityProject/` in Unity 2022.3 LTS.
2) Open `Assets/Scenes/Main.unity` (provided).
3) Press **Play**. Keys: 1–7 (child stations), F1–F6 (family), B (Baby Mode),
   T/S/C/L (talk/sing/clap/read demo). Open AskMom via the menu button in the scene.
4) Build using settings in `Docs/Build_Profiles.txt`.

## Scenes
- **Main.unity** – hub that loads stations and has a portal button to **AskFaithFriendMom.unity**.
- **AskFaithFriendMom.unity** – interactive Q&A station for parents.

## Platform TTS
- iOS: AVSpeechSynthesizer (plugins/iOS/TTSBridge.mm)
- Android/Quest: Android TextToSpeech
- Windows: PowerShell System.Speech
- macOS: `say` command

Everything runs **offline** (speech recognition stub included for Editor testing).
