using UnityEngine; using System.Runtime.InteropServices; using System.Diagnostics;
public class TalkSingClapTTS:MonoBehaviour
{
    public static string Language="en-US";
#if UNITY_ANDROID && !UNITY_EDITOR
    private AndroidJavaObject tts; private bool ready=false;
    private class OnInit:AndroidJavaProxy{ TalkSingClapTTS o; public OnInit(TalkSingClapTTS x):base("android.speech.tts.TextToSpeech$OnInitListener"){o=x;} void onInit(int s){o.ready=(s==0);} }
    void Start(){ var up=new AndroidJavaClass("com.unity3d.player.UnityPlayer"); var act=up.GetStatic<AndroidJavaObject>("currentActivity"); tts=new AndroidJavaObject("android.speech.tts.TextToSpeech",act,new OnInit(this)); }
#endif
    public void Talk(string t){ Speak(t); FindObjectOfType<HapticsEngine>()?.PlayPattern("enter"); }
    public void Sing(string t){ Speak("Singing: "+t); FindObjectOfType<HapticsEngine>()?.PlayPattern("joy"); }
    public void Clap(string p){ Speak("Clap clap for you!"); FindObjectOfType<HapticsEngine>()?.PlayPattern("joy"); }
    public void Speak(string text){
#if UNITY_ANDROID && !UNITY_EDITOR
        if(!ready||tts==null){ UnityEngine.Debug.Log("[TTS] Android not ready."); return; }
        tts.Call<int>("setLanguage", new AndroidJavaObject("java.util.Locale", Language));
        tts.Call<int>("speak", text, 0, null, "utteranceId");
#elif UNITY_IOS && !UNITY_EDITOR
        _SpeakIOS(text, Language);
#elif UNITY_STANDALONE_OSX && !UNITY_EDITOR
        Run("/usr/bin/say", "-v Samantha "+Quote(text));
#elif UNITY_STANDALONE_WIN && !UNITY_EDITOR
        string ps="Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('"+text.replace("'","''")+"');";
        Run("powershell.exe","-NoProfile -Command "+Quote(ps));
#else
        UnityEngine.Debug.Log("[TTS Simulated] "+text);
#endif
    }
#if UNITY_IOS && !UNITY_EDITOR
    [DllImport("__Internal")] private static extern void _SpeakIOS(string message,string lang);
#endif
#if UNITY_STANDALONE && !UNITY_EDITOR
    private static void Run(string file,string args){ try{ var p=new Process(); p.StartInfo.FileName=file; p.StartInfo.Arguments=args; p.StartInfo.CreateNoWindow=true; p.StartInfo.UseShellExecute=false; p.Start(); }catch(System.Exception e){ UnityEngine.Debug.LogWarning(e.Message);} }
    private static string Quote(string s)=>"\""+s.replace("\"","\\\"")+"\"";
#endif
}