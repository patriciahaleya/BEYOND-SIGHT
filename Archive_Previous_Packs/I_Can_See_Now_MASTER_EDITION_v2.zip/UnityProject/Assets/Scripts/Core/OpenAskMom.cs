using UnityEngine; using UnityEngine.SceneManagement;
public class OpenAskMom:MonoBehaviour { public void Open(){ SceneManager.LoadScene("AskFaithFriendMom"); } }