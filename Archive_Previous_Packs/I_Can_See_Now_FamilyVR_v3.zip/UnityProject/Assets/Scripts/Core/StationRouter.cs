using UnityEngine;
using System.Collections.Generic;

public class StationRouter : MonoBehaviour
{
    public AudioSource Ambience;
    public AudioSource Sfx;
    public HapticsEngine Haptics;
    public AromaController Aroma;

    public void Init(List<StationDefinition> defs) {}

    public void SwitchTo(StationDefinition def)
    {
        if (Aroma!=null) Aroma.Emit(def.aroma, 0.5f);
        if (Haptics!=null) Haptics.PlayPattern(string.IsNullOrEmpty(def.haptics)?"enter":def.haptics);
        if (Ambience!=null) { Ambience.spatialBlend = 1f; Ambience.pitch = Random.Range(0.95f,1.05f); Ambience.Play(); }
        EventBus.Broadcast("ui.prompt", def.voice);
    }

    public void RandomizeVariation()
    {
        if (Ambience!=null) { Ambience.pitch = Random.Range(0.85f,1.15f); Ambience.volume = Random.Range(0.5f,1.0f); }
        if (Sfx!=null) Sfx.Play();
        if (Haptics!=null) Haptics.PlayPattern("random");
        EventBus.Broadcast("env.randomize","");
    }
}
