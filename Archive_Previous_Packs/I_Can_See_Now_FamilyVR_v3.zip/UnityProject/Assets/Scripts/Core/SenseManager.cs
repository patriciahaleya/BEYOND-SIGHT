using UnityEngine;
using System.Collections.Generic;

public class SenseManager : MonoBehaviour
{
    public StationRouter Router;
    public FaithFriendRealtime Friend;
    private List<StationDefinition> stations = new List<StationDefinition>();

    void Awake()
    {
        stations = StationConfigLoader.Load();
        Router.Init(stations);
        SwitchTo(0);
    }

    void Update()
    {
        for (int i=0;i<7;i++) if (Input.GetKeyDown(KeyCode.Alpha1+i)) SwitchTo(i);
        if (Input.GetKeyDown(KeyCode.F1)) SwitchTo(7);
        if (Input.GetKeyDown(KeyCode.F2)) SwitchTo(8);
        if (Input.GetKeyDown(KeyCode.F3)) SwitchTo(9);
        if (Input.GetKeyDown(KeyCode.F4)) SwitchTo(10);
        if (Input.GetKeyDown(KeyCode.F5)) SwitchTo(11);
        if (Input.GetKeyDown(KeyCode.F6)) SwitchTo(12);

        if (Input.GetKeyDown(KeyCode.R)) Router.RandomizeVariation();
        if (Input.GetKeyDown(KeyCode.M)) Friend.PlayRequestedSong("Happy");
        if (Input.GetKeyDown(KeyCode.V)) Friend.SimulateQuestion();
        if (Input.GetKeyDown(KeyCode.H)) HapticsEngine.Instance.CyclePattern();
    }

    public void SwitchTo(int i)
    {
        var defs = StationConfigLoader.Load();
        if (i < 0 || i >= defs.Count) return;
        var def = defs[i];
        Router.SwitchTo(def);
        if (Camera.main) Camera.main.backgroundColor = def.UnityColor();
        EventBus.Broadcast("station.changed", def.name);
        Debug.Log("[SenseManager] Station → " + def.name);
    }
}
