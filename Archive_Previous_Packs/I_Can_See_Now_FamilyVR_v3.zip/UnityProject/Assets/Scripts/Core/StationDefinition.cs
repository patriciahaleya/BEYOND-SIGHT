using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class StationDefinition
{
    public int id;
    public string name;
    public string color;
    public string accent;
    public string[] gradient;
    public string aroma;
    public string ambience;
    public List<string> textures;
    public string haptics;
    public string music;
    public string voice;

    public Color UnityColor()
    {
        Color c;
        if (ColorUtility.TryParseHtmlString(color, out c)) return c;
        return Color.black;
    }
}
