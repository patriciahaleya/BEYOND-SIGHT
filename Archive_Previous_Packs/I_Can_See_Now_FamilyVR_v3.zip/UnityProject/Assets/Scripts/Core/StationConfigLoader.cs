using UnityEngine;
using System.Collections.Generic;

public static class StationConfigLoader
{
    [System.Serializable] class Wrapper { public List<StationDefinition> stations; }
    public static List<StationDefinition> Load()
    {
        var json = Resources.Load<TextAsset>("Config/Stations_v3");
        if (json == null) { Debug.LogWarning("Stations_v3.json not found"); return new List<StationDefinition>(); }
        var w = JsonUtility.FromJson<Wrapper>(json.text);
        return w.stations;
    }
}
