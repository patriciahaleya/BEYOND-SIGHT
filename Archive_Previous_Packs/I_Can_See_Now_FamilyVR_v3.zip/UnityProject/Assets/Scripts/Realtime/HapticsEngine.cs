using UnityEngine;
using System.Collections.Generic;

public class HapticsEngine : MonoBehaviour
{
    public static HapticsEngine Instance;
    void Awake(){ Instance=this; }
    public void CyclePattern(){ Handheld.Vibrate(); }
    public void PlayPattern(string name, float intensity=0.7f){ Handheld.Vibrate(); }
}
