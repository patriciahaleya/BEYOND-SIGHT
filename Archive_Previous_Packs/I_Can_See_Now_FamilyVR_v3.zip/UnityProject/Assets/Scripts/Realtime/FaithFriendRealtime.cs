using UnityEngine; using System.Collections;
public class FaithFriendRealtime:MonoBehaviour{
 public AudioSource Voice; public AudioSource Music; public VoiceInput Input;
 void Awake(){ if(Input!=null) Input.OnTranscript+=OnQ; }
 public void SimulateQuestion(){ if(Input!=null) Input.SimulateAsk(); }
 void OnQ(string t){ Debug.Log("[FaithFriend] Q: "+t); if(t.ToLower().Contains("sing")){ if(Music) Music.Play(); } else if(Voice) Voice.Play(); }
 public void PlayRequestedSong(string title){ if(Music) Music.Play(); }
}