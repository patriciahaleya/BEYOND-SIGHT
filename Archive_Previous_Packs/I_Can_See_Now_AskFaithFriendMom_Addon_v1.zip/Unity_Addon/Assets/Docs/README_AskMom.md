# Ask FaithFriend Mom — Add-On (v1)
Generated: 2025-10-27

This drop-in package adds a **new station/scene** to your MASTER EDITION app,
where parents can ask questions and hear loving answers in real time.

## What's Included
- **Scene**: `AskFaithFriendMom.unity` (stub placeholder; open and add your visuals)
- **Scripts**:
  - `FaithFriendMomManager.cs` – drives flow, loads Q&A, plays TTS answers
  - `SpeechRecognizerStub.cs` – simple editor/desktop speech simulation (replace later with platform SR)
  - `MomUILines.cs` – optional quick UI prompts
- **Configs**:
  - `AskMom_QA.json` – curated questions & answers
  - `Parent_Resources.json` – resource cards (Early Intervention, Therapies, Faith support, State registry)
  - `Create_Games_Ideas.json` – parent-made sensory game templates
- **Docs**:
  - Setup steps (copy/paste) and integration guide

## Install (2 minutes)
1) Unzip. Drag the **Unity_Addon/Assets/** folder into your Unity project (same root as `Assets/`).
2) Open scene `Assets/Scenes/AskFaithFriendMom.unity` OR make a portal button in your hub that loads it.
3) In the scene, create an empty object **AskMom** and add:
   - `FaithFriendMomManager`
   - `TalkSingClapTTS` (TTS already in MASTER)
   - `SpeechRecognizerStub` (for Editor/PC testing)
   - `MomUILines` (optional)
4) Press **Play**. Type a question in the input box or press **J/K/L** to demo questions. Answers speak via TTS.

## Go Live (later)
- Replace `SpeechRecognizerStub` with your platform's speech recognition.
- Hook scent & haptics if desired (AromaController + HapticsEngine on the same GameObject).
