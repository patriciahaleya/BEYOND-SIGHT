using UnityEngine;
using System.Linq;

public class FaithFriendMomManager : MonoBehaviour
{
    public TalkSingClapTTS TTS;
    public TextAsset QAJson;
    public TextAsset ResourcesJson;
    public TextAsset GamesJson;

    [System.Serializable] public class QAItem{ public string q; public string a; }
    [System.Serializable] public class QAWrapper{ public QAItem[] faq; }
    [System.Serializable] public class Card{ public string title; public string desc; public string action; }
    [System.Serializable] public class CardWrap{ public Card[] cards; }
    [System.Serializable] public class GameIdea{ public string name; public string how; }
    [System.Serializable] public class GameWrap{ public GameIdea[] ideas; }

    private QAWrapper _qa;
    private CardWrap _res;
    private GameWrap _games;

    void Awake()
    {
        if (TTS==null) TTS = FindObjectOfType<TalkSingClapTTS>();
        if (QAJson!=null) _qa = JsonUtility.FromJson<QAWrapper>(QAJson.text);
        if (ResourcesJson!=null) _res = JsonUtility.FromJson<CardWrap>(ResourcesJson.text);
        if (GamesJson!=null) _games = JsonUtility.FromJson<GameWrap>(GamesJson.text);
        AnnounceWelcome();
    }

    void AnnounceWelcome()
    {
        if (TTS!=null) TTS.Talk("Welcome, sweet mama. Ask me anything. I am here with you.");
    }

    public void AskQuestion(string text)
    {
        if (string.IsNullOrEmpty(text)) return;
        // Simple match to closest FAQ for now
        var best = _qa.faq.FirstOrDefault();
        int bestScore = -1;
        foreach (var item in _qa.faq)
        {
            int score = SimilarityScore(text.ToLower(), item.q.ToLower());
            if (score > bestScore){ bestScore = score; best = item; }
        }
        TTS?.Talk(best.a);
    }

    public void ReadResource(int index)
    {
        if (_res==null || _res.cards==null || index<0 || index>=_res.cards.Length) return;
        var c = _res.cards[index];
        TTS?.Talk(c.title + ". " + c.desc + " " + c.action);
    }

    public void SuggestGame(int index)
    {
        if (_games==null || _games.ideas==null || index<0 || index>=_games.ideas.Length) return;
        var g = _games.ideas[index];
        TTS?.Talk("Let's try a game. " + g.name + ". " + g.how);
    }

    // Very simple similarity heuristic
    int SimilarityScore(string a, string b)
    {
        int score = 0;
        foreach (var w in a.Split(' ')) if (b.Contains(w)) score++;
        return score;
    }
}
